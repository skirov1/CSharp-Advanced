﻿using System;

namespace _02.CarExtension
{
    public class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
