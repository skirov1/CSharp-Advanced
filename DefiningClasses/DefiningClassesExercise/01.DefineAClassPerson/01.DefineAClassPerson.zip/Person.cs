﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
     class Person
    {
        private string name;
        private int age;

        public string Name { get; set; }
        public int Age { get; set; }
    }
}
