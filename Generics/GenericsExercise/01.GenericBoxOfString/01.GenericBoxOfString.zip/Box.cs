﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.GenericBoxOfString
{
    public class Box<T>
    {
        public string Text { get; set; }
        public override string ToString()
        {
            return $"{Text.GetType()}: {this.Text}";
        }
    }
}
